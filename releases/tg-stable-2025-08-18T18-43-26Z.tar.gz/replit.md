# Mork F.E.T.C.H Bot

## Overview
Mork F.E.T.C.H Bot, "The Degens' Best Friend," is a production-ready Telegram-based cryptocurrency trading bot for Solana blockchain tokens, specifically those on Pump.fun. Its purpose is to enable fast execution and control over trades. Key capabilities include secure wallet management, Jupiter DEX integration, comprehensive safety checks, and MORK holder access gates. The business vision is to provide a user-friendly, automated trading solution for Solana degens, enhancing their trading efficiency and profitability.

## User Preferences
Preferred communication style: Simple, everyday language.
Brand colors: Mork Coin branding with green primary color (#7cb342) and light green accent (#9ccc65) to match current brand guidelines.
Branding rules: "Mork F.E.T.C.H Bot" text should be dark green (#1a2e0a) on light green backgrounds, all other text should be white unless they are headline text. The bot is positioned as "The Degens' Best Friend" with playful dog-themed messaging around "fetching" profits and "sniffing" trades. F.E.T.C.H. = Fast Execution, Trade Control Handler. Uses casual, meme-friendly language appealing to crypto degenerates while maintaining professionalism.

## System Architecture
The application uses Flask with a polling-based architecture for Telegram integration, managing session states and database persistence with SQLAlchemy. A finite state machine handles multi-step user interactions. UI/UX aligns with Mork Coin branding. The system supports Simulation, Manual Live Trading (`/snipe`), and Automated VIP Trading (`/fetch`) modes.

**Core Architectural Decisions & Features:**
- **Dual-Service Architecture:** Flask web application and polling bot run with distinct configurations, preventing import conflicts and enabling separate functionalities. The web app can utilize full scanner functionality, while the polling bot operates independently for Telegram.
- **Robust Message Delivery:** Implemented a 3-tier fallback system for Telegram message delivery (MarkdownV2 → escaped MarkdownV2 → plain text) with resilient timeout handling and streamlined parsing for zero-width characters and robust @BotName handling.
- **Automated Restart Mechanisms:** Both `run.sh` and `simple_polling_bot.py` include robust auto-restart mechanisms with infinite loops and exception handling for maximum uptime.
- **Multi-Source Token Discovery & Scoring:** Integrates Birdeye, Jupiter, and Solscan Pro for comprehensive token discovery, enrichment, and scoring with real-time processing and automatic reconnection.
- **AI Assistant System:** Flask webhook integration supporting multiple AI models with intelligent fallback and persistent storage.
- **Live Monitoring & Diagnostics:** Secure, token-gated interfaces for real-time event streaming via Server-Sent Events (SSE) and an ultra-lightweight console, alongside a complete diagnostic system for live module reloading and endpoint monitoring.
- **Enhanced Event Publishing System:** Advanced real-time event tracking with deduplication across all system components, featuring a thread-safe publish/subscribe architecture.
- **Telegram Integration:** Production-ready polling mode integration with comprehensive admin command routing and unified command processing, using `simple_polling_bot.py` for direct Telegram API polling.
- **Enhanced Logging System:** Dual-layer logging with `RotatingFileHandler` and `RingBufferHandler`.
- **Simplified Scanner Control System:** Self-contained scanner module with JSON persistence, enabling granular controls via Telegram commands for toggling, threshold adjustment, watchlist management, and real-time configuration updates.
- **Mock Data Testing System:** Comprehensive testing infrastructure for realistic token generation and advanced scoring, integrated with the scanner system for background alerts and instant scanning via `/fetch_now`.
- **Trade Management System:** Self-contained `trade_store.py` module with JSON persistence for position tracking, fill recording, and pending action management.
- **Mock Trading Engine:** `trade_engine.py` module providing realistic buy/sell operations with slippage simulation, preview/execution functions, and integration with `trade_store`.
- **Complete Mock Trading System:** Comprehensive trading functionality with preview/confirmation flow, position tracking, PnL tracking, and integrated safety systems.
- **Autobuy Functionality:** Enhanced scanner state with autobuy configuration for automated token purchases based on scanner alerts, featuring per-token configuration and safety caps.
- **AutoSell System:** Fully operational sophisticated automated selling engine with take-profit, stop-loss, and trailing stop functionality. Enhanced with real Dexscreener API integration (5-second intelligent caching), simulated price fallback, rule state management, rolling event logging, and enterprise-grade watchdog monitoring with admin alerts. Features a comprehensive 18-command Telegram suite for rule management, persistence, and control, plus public `/price <mint>` command for real-time price lookups.
- **Watchlist Alert System:** Real-time price monitoring with configurable percent-change thresholds for generating alerts when token prices move significantly. Integrated with AutoSell tick evaluation for seamless monitoring alongside trading rules. Features 7-command admin suite: `/watch`, `/unwatch`, `/watchlist`, `/watch_sens`, `/autosell_restore`, `/alerts_on`, and `/alerts_off`. Includes comprehensive state persistence with automatic save on all changes, configurable sensitivity (0.1%-100%), and toggle controls for muting/unmuting alerts while preserving watchlist data.
- **Paper Trade Ledger System:** Complete DRY-RUN trading ledger with position tracking, average cost calculation, and comprehensive P&L management. Features 11-command admin suite: `/paper_buy`, `/paper_sell`, `/ledger`, `/ledger_reset`, `/ledger_pnl`, `/paper_setprice`, `/paper_clearprice`, `/ledger_pnl_csv`, `/paper_auto_on`, `/paper_auto_off`, and `/paper_auto_status`. Integrated with AutoSell state persistence for cross-restart durability. Supports automatic price discovery, manual price specification, and mark-to-market valuation with unrealized P&L calculations. Advanced features include real-time portfolio valuation, per-position unrealized gains/losses, manual price overrides with cleanup management, structured CSV export for analysis and reporting, and automated paper trading on alert events with configurable trade quantities and safe demo mode operation.
- **Alert Routing System:** Real-time alert forwarding to specified Telegram groups or channels with advanced flood control and persistent configuration. Features comprehensive 8-command admin suite: `/alerts_chat_set <chat_id>`, `/alerts_chat_set_here` (auto-detects current chat), `/alerts_chat_clear`, `/alerts_chat_status`, `/alerts_test <message>`, `/alerts_min_move <percent>` (threshold filtering), `/alerts_rate <N_per_min>` (rate limiting), and `/alerts_settings` (detailed status). Only [ALERT] and [AUTO] events are forwarded to prevent spam. Advanced flood control includes percentage-based threshold filtering to block minor price movements and sliding-window rate limiting to prevent excessive alerts. State persists across restarts via `alert_chat.json`. The auto-detection feature allows easy setup directly in target groups/channels without manual chat ID lookup. Seamlessly integrates with existing AutoSell watchlist alerts and Paper-Auto automated trading events for centralized alert distribution to trading groups and channels.
- **Snapshot/Restore System:** Quality-of-life backup management with point-in-time snapshots and dual-file persistence architecture. Features 4-command admin suite: `/autosell_backup`, `/autosell_restore_backup`, `/autosell_save`, and enhanced `/autosell_restore`. Enables configuration rollback scenarios, experimental state management, and comprehensive backup/restore workflows for all AutoSell, watchlist, and ledger data with atomic file operations and error handling.
- **Enhanced Wallet System:** Secure two-step wallet reset, QR deposit system, comprehensive diagnostics, and a full 12-command wallet suite.
- **Real-time SOL Price Integration:** Live CoinGecko API integration with intelligent caching and multi-level fallback protection.
- **Elegant Bridge Pattern Messaging System:** Centralized `send_message()` bridge function for unified Telegram API control.
- **Comprehensive Token Balance System:** Enhanced `/wallet_balance` command showing all SPL tokens with automatic discovery and metadata parsing.
- **Streamlined Centralized Messaging:** Ultra-clean centralized messaging pattern with enhanced MarkdownV2 system and bulletproof message delivery.
- **Smart Unknown Command Handling:** Professional error messages with text sanitization, distinguishing between commands and regular text.
- **Unified Handler Architecture:** Single-point update processing with enhanced idempotency for message and edited_message updates, and a rolling memory system to prevent duplicate message processing.
- **Webhook Conflict Resolution:** Automatic webhook deletion when polling starts.

## External Dependencies
- **Telegram Bot API**: For all message handling and user interactions.
- **Solana Blockchain Integration**: Interacts with the Solana blockchain for live trading on Pump.fun.
- **Flask Web Server**: The application's web server for webhook callbacks and web interface.
- **SQLAlchemy**: For database abstraction (defaults to SQLite).
- **Python HTTP Requests**: The `requests` library for all HTTP communication with external APIs.
- **OpenAI API**: For AI assistant functionalities.
- **Jupiter DEX**: For decentralized exchange operations on Solana.
- **PumpPortal Lightning Transaction API**: The core trading engine for verified token delivery on Pump.fun.
- **Birdeye API/WebSocket**: For real-time token data and discovery.
- **token.jup.ag API**: For fetching Jupiter token lists.
- **Solscan API**: For blockchain data and new token discovery.
- **DexScreener API**: For Solana pairs monitoring, token data, and real-time price feeds with intelligent caching.